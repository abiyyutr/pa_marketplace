<?php
header ('Location:http://401xd.com/');
?>